/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp05;

/**
 *
 * @author SplFernaD
 */
public class MinhaThend extends Thread {
   private int maximo;
   private int prioridade;
   private String retorno;
   
   public MinhaThend(int maxim, int pri){
   this.maximo= maxim;
   this.prioridade = pri;
   start();
   
   }
   public void run(){
       for (int i=0; i < this.maximo; i++ ){
       this.retorno =this.retorno + i;
       }
   }
   
   
}
